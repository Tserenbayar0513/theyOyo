import React from 'react'
import ReactDOM from 'react-dom/client'
import TheyOSite from './TheyOSite'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <TheyOSite />
  </React.StrictMode>,
)